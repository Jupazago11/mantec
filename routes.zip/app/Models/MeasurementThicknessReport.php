<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class MeasurementThicknessReport extends Model
{
    protected $fillable = [
        'element_id',
        'report_date',
        'created_by',
        'published_at',
        'notes',
    ];

    protected function casts(): array
    {
        return [
            'report_date' => 'date',
            'published_at' => 'datetime',
        ];
    }

    public function element(): BelongsTo
    {
        return $this->belongsTo(Element::class, 'element_id');
    }

    public function creator(): BelongsTo
    {
        return $this->belongsTo(User::class, 'created_by');
    }

    public function lines(): HasMany
    {
        return $this->hasMany(MeasurementThicknessReportLine::class, 'report_id')
            ->orderBy('cover_number');
    }
}